var id = ''
Page({
  /**
   * 页面的初始数据
   */
  data: {
    totalPrice:0,
    user_name: '',
    goods_name: '',
    now_state: null,
    list: [],
    img: '',
    scr: '',
    reason1: '',
    reason2: '',
    reason3: '',
    reason: '',
  },
  reason1: function (e) {


    this.setData({
      reason1: "商品出现破损或变质"
    })

    console.log("点击退款原因一返回数据", this.data.reason1)
  },
  reason2() {

    this.setData({
      reason2: "实物与图片差异较大"
    })

    console.log("点击退款原因二返回数据", this.data.reason2)
  },
  reason3() {

    this.setData({
      reason3: "其他原因"
    })

    console.log("点击退款原因三返回数据", this.data.reason3)

  },
  listenFormSubmit: function (e) {
    console.log("发生了submit事件", e.detail.value);
  },

  listenFormResert: function (e) {
    console.log("发生了resert事件");
  },
  onLoad() {
    wx.cloud.database().collection('orders')
      .where({
        status: 2 //请求订单状态为已完成的订单
      })
      
      .orderBy("_createTime", 'desc')
      .get()
      .then(res => {
        console.log("请求成功", res)
        this.setData({
          list: res.data
        })
      }).catch(res => {
        console.log("请求失败", res)
      })
  },
  //请求需要退款的订单的数据
  getList() {
    let id = this.data.id
    let img = this.data.img
    wx.cloud.database().collection('orders')
      .doc(id)
      .get()
      .then(res => {
        console.log("请求需要退款的订单的数据成功", res)
        this.setData({
          user_name: res.data.name,
          img: res.data.img,
          goods_name: res.data.good.name,
          name: res.data.chiefName,
          totalPrice: res.data.totalPrice,
          quantity: res.data.good.quantity,
        })
        // let user_name = this.data.user_name
        // console.log("所上传的申请退款的商品名", user_name)

      }).catch(res => {
        console.log("请求需要退款的订单的数据失败", res)
      })
  },

  //申请退款 往退款申请里填加一条数据
  add() {
    let quantity = this.data.quantity
    let chiefname = this.data.name
    let id = this.data.id
    console.log("所上传的申请退款的id", id)
    let name = this.data.goods_name
    console.log("所上传的申请退款的商品名", name)
    let user_name = this.data.user_name
    console.log("上传的申请退款的用户名", user_name)
    let goods_img = this.data.img
    console.log("所上传的申请退款的商品图", goods_img)
    let img = this.data.src
    let totalPrice = this.data.totalPrice
    console.log("所上传的申请退款的图片", img)
    // let reason = this.data.reason1
    let reason = this.data.reason1 + " " + this.data.reason2 + " " + this.data.reason3
    console.log("所上传的申请退款的原因", reason)
    wx.cloud.database().collection('tuikuan')
      .add({ //添加数据
        data: {
          quantity:quantity,
          prices: totalPrice,
          tz_name: chiefname,
          goods_name: name,
          user_name: user_name,
          order_id: id,
          img: img,
          goods_img: goods_img,
          reason: reason,
          status: 0
        }
      })
      .then(res => {
        console.log('添加成功', res)

      })
      .catch(err => {
        console.log('添加失败', err)
      })
  },
  update() {
    let id = this.data.id
    console.log("传递到update的id值", id);
    wx.cloud.database().collection('goods')
      .doc(id) //doc查询相应的商品ID 后进行修改
      .update({
        data: {
          status: -2
        } //只用写需要修改的属性
      })
      .then(res => {
        console.log('修改成功', res)

      })
      .catch(err => {
        console.log('修改失败', err)
      })
  },

  sure: function (e) {
    console.log("点击申请退款所携带的订单id", e.currentTarget.dataset.id)
    let id = e.currentTarget.dataset.id
    this.setData({
      id: id
    })
    var that = this
    that.setData({
      now_state: true
    })
    console.log(that.data.now_state);
    this.getList()
  },
  hideModal(e) {
    //首先创建一个动画对象（让页面不在是一个“死页面”）
    var animation = wx.createAnimation({
      duration: 200,
      timingFunction: "linear",
      delay: 0
    })
    this.animation = animation
    //animation.translateY(300)中的translate函数是表示在y轴上平移多少px，而后面紧接着的.step表示前面动画的完成，可以开始下一个动画了
    animation.translateY(300).step()
    this.setData({
      /*这里的export函数是导出动画队列，在外米的wxml中会用到该数据，同时export方法在调用完后会清掉前面的动画操作 */
      animationData: animation.export(),
    })
    /*这里的setTimeout是一个延时器，而它在这里延时了200ms，然后在执行动画 */
    setTimeout(function () {
      animation.translateY(0).step()
      this.setData({
        animationData: animation.export(),
        now_state: false,
      })
    }.bind(this), 200)
    var that = this

  },
  ok: function () {
    this.add()
    this.update()
    wx.showToast({
      title: '提交成功！', // 标题
      icon: 'success', // 图标类型，默认success
      duration: 1800 // 提⽰窗停留时间，默认1500ms
    })
    var animation = wx.createAnimation({
      duration: 200,
      timingFunction: "linear",
      delay: 0
    })
    this.animation = animation
    //animation.translateY(300)中的translate函数是表示在y轴上平移多少px，而后面紧接着的.step表示前面动画的完成，可以开始下一个动画了
    animation.translateY(300).step()
    this.setData({
      /*这里的export函数是导出动画队列，在外米的wxml中会用到该数据，同时export方法在调用完后会清掉前面的动画操作 */
      animationData: animation.export(),
    })
    /*这里的setTimeout是一个延时器，而它在这里延时了200ms，然后在执行动画 */
    setTimeout(function () {
      animation.translateY(0).step()
      this.setData({
        animationData: animation.export(),
        now_state: false,
      })
    }.bind(this), 200)
    var that = this
  },
  chooseImage: function () {
    var that = this
    wx.chooseImage({
      count: 2,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success: function (res) {
        var tempFilePaths = res.tempFilePaths
        that.setData({
          src: tempFilePaths[0],
          src1: tempFilePaths[1]
        })
      }
    })
  },

  previewImage: function () {
    var that = this
    wx.previewImage({
      urls: [this.data.src]
    })
  },
  //  getImageInfo:funcrion(){
  //       var that =this
  //       wx.getImageInfo({
  //         src:this.data.src,
  //         success:function(res){
  //       wx.showToast({
  //         icon:'none',
  //         title: '宽'+res.width+'高'+res.height,
  //       })
  //         },
  //       }),
  //     }
  //上传图片
  getImageInfo: function () {
    var that = this
    wx.getImageInfo({
      src: this.data.src,
      success: function (res) {
        wx.showToast({
          icon: 'none',
          title: '宽' + res.width + '高' + res.height
        })
      }
    })
  },
  //上传图片到云存储
  uploadFile(temFile, fileName) {
    console.log("要上传文件的临时路径", temFile)
    wx.cloud.uploadFile({
      cloudPath: fileName,
      filePath: temFile, // 临时文件文件路径
      success: res => {
        // get resource ID
        console.log("上传成功", res)
        this.setData({
          imgUrl: res.fileID
        })
      },
      fail: err => {
        // handle error
        console.log("上传失败", err)
      }
    })

  }

})