Page({
  data: {
    inputname: '',
    inputphone: '',
    Inputaddress: '',
    Inputaddress_detail: ''

  },
  ok: function () {
    let name = this.data.inputname
    let phoneNum = this.data.inputphone
    let address = this.data.Inputaddress
    let address_detail = this.data.Inputaddress_detail
    wx.cloud.database().collection('members').add({
      data: {
        name: name,
        phoneNum: phoneNum,
        address: address,
        address_detail: address_detail,
        status:0
      },
     
      success(res) {
        console.log("保存成功!", res)
        wx.showToast({
          title: '保存成功！', // 标题
          icon: 'success', // 图标类型，默认success
          duration: 1800 // 提⽰窗停留时间，默认1500ms
        })
      },
      fail(res) {
        console.log("注册失败", console.res)
      }
    })
  },

  bindKeyInput: function (e) {
    this.setData({
      inputname: e.detail.value
    })
    console.log(e.detail.value)
  },
  Inputphone: function (e) {
    this.setData({
      inputphone: e.detail.value
    })
    console.log(e.detail.value)
  },
  InputAddress: function (e) {
    this.setData({
      Inputaddress: e.detail.value
    })
    console.log(e.detail.value)
  },
  InputAddress_detail: function (e) {
    this.setData({
      Inputaddress_detail: e.detail.value
    })
    console.log(e.detail.value)
  },

})