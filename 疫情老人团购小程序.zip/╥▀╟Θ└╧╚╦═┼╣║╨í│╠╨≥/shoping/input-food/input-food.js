// pages/input-food/input-food.ts
let name = ""
let num = ""
let price = ""
let type = ""
Page({

  /**
   * 页面的初始数据
   */
  data: {
    src: '',
    selected:1
  },
  //获取用户输入的商品名
  getName(e) {
    name = e.detail.value
    console.log("新输入的商品名", name)
  },
  //获取用户输入的商品类型 
  getType(e) {
    type = e.detail.value
    console.log("新输入的价格", type)
  },
  //获取用户输入的价格 
  getPrice(e) {
    price = e.detail.value
    console.log("新输入的价格", price)
  },
  //获取用户输入的数量 
  getNum(e) {
    num = e.detail.value
    console.log("新输入的商品数 ", num)
  },

  listenFormSubmit: function (e) {
    console.log("发生了submit事件", e.detail.value);
  },

  listenFormResert: function (e) {
    console.log("发生了resert事件");
  },

  chooseImage: function () {
    var that = this
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success: function (res) {
        var tempFilePaths = res.tempFilePaths
        that.setData({
          src: tempFilePaths[0],
       
        })
      }
    })
  },


  //添加新商品
  add() {
   
    console.log("上传的商品图片",this.data.src)
    let img = this.data.src
    wx.cloud.database().collection('goods')
      .add({ //添加数据
        data: {
          name: name,
          price: price,
          num: num,
          type: type,
          img: img,
          status:"上架",
          selected:1
        }
      })
      .then(res => {
        console.log('添加成功', res)

      }).catch(err => {
        console.log('添加失败', err)
      })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad() {

  },

  

 


})