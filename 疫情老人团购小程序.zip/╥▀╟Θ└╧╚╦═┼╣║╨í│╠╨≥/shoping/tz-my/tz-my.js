
Page({
      data: {
        list: [],
        totalPrice: 0, //总收入
        totalNum: 0, //总数量
        userInfo:'',
        src:'',
        selected: 2
      },
      all: function () {
        wx.navigateTo({
          url: '../tz-all/tz-all',
        })
      },
      wait: function () {
        wx.navigateTo({
          url: '../send/send',
        })
      },
      back: function () {
        wx.navigateTo({
          url: '../tz-serve/tz-serve',
        })
      },
      //获取数据
      getList() {
        wx.cloud.database().collection('order')
          .where({
            chiefName: "八戒",
            // status: 1
          })
          .get()
          .then(res => {
            console.log("请求成功", res)
            this.setData({
              list: res.data
            })
          }).catch(res => {
            console.log("请求失败", res)
          })
      },
      onLoad() {
        let user=wx.getStorageSync('user')
        console.log('进入小程序的页面获取缓存',user.nickName)
        console.log('进入小程序的页面获取缓存',user.avatarUrl)
        this.setData({
          userInfo:user.nickName,
          scr:user.avatarUrl
        })

        this.getList()

        let list = this.data.list
        console.log(" ...", this.data.list)
        list.forEach(item => {
            item.num += 1
            this.setData({
              totalMoney: this.data.totalMoney += item.prices,
              totalNum: this.data.totalNum += 1
            })
          }

        )}
      })