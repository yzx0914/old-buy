// components/shoping-tabbar/index.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    selected: {
      type: Number,
      default:0
    }
  },  

  /**
   * 组件的初始数据
   */
  data: {
    selected:0,
    color: "#7A7E83",
    selectedColor: "#3cc51f",
    list: [
      {
        pagePath: "/shoping/people-index/people-index",
        text: "首页",
        iconPath: "/static/images/tabbar/首页 (1).png", 
        selectedIconPath: "/static/images/tabbar/首页.png"
      },
     
      {
        pagePath: "/shoping/input-food/input-food",
        text: "编辑",
        iconPath: "/static/images/tabbar/编辑 (1).png",
        selectedIconPath: "/static/images/tabbar/编辑.png"
      },
      {
        pagePath: "/shoping/tz-my/tz-my",
        text: "我的",
        iconPath: "/static/images/tabbar/我的 (1).png",
        selectedIconPath: "/static/images/tabbar/我的.png"
      }
    ]
  },


  /**
   * 组件的方法列表
   */
  methods: {
    switchTab(e) {
      let data = e.currentTarget.dataset
      let url = data.path
      wx.redirectTo({
        url
      })
    }
  }
})
